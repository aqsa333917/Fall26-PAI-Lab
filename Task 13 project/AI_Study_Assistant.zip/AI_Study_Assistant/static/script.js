function sendMessage() {
    let input = document.getElementById("userInput");
    let message = input.value;

    if (message === "") return;

    addMessage(message, "user");

    fetch("/ask", {
        method: "POST",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify({ question: message })
    })
    .then(res => res.json())
    .then(data => {
        addMessage(data.answer, "bot");
    });

    input.value = "";
}

function addMessage(text, type) {
    let chatbox = document.getElementById("chatbox");

    let msg = document.createElement("div");
    msg.classList.add("message");
    msg.classList.add(type);
    msg.innerText = text;

    chatbox.appendChild(msg);
    chatbox.scrollTop = chatbox.scrollHeight;
}

function clearChat() {
    document.getElementById("chatbox").innerHTML = "";
}