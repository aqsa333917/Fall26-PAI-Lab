import nltk
import re
import pickle
import pandas as pd
from nltk.corpus import stopwords

nltk.download('stopwords')
stop_words = set(stopwords.words('english'))

# load model
model = pickle.load(open("models/model.pkl", "rb"))
vectorizer = pickle.load(open("models/vectorizer.pkl", "rb"))

df = pd.read_csv("data/dataset.csv")
intent_map = dict(zip(df['intent'], df['answer']))

# ---------------- NLP CLEANING ----------------
def clean_text(text):
    text = text.lower()
    text = re.sub(r'[^\w\s]', '', text)
    
    words = text.split()
    words = [w for w in words if w not in stop_words]
    
    return " ".join(words)

# ---------------- PREDICT ----------------
def get_answer(question):
    question = clean_text(question)

    vec = vectorizer.transform([question])
    intent = model.predict(vec)[0]

    return intent_map.get(intent, "Sorry, I don't know the answer.")