from flask import Flask, render_template
import requests

app = Flask(__name__)

API_KEY = "PI2dMuMnearajRifFiWvIFeMgvmkTcinTbQbtLbE"

@app.route("/")
def index():
    url = f"https://api.nasa.gov/insight_weather/?api_key={API_KEY}&feedtype=json&ver=1.0"

    response = requests.get(url)
    data = response.json()

    sol_keys = data.get("sol_keys", [])
    weather_data = []

    for sol in sol_keys:
        temp = data[sol]["AT"]["av"] if "AT" in data[sol] else "N/A"
        wind = data[sol]["HWS"]["av"] if "HWS" in data[sol] else "N/A"
        season = data[sol]["Season"] if "Season" in data[sol] else "N/A"

        weather_data.append({
            "sol": sol,
            "temperature": temp,
            "wind": wind,
            "season": season
        })

    return render_template("index.html", weather=weather_data)

if __name__ == "__main__":
    app.run(debug=True)